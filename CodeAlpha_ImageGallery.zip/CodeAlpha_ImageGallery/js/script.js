
// .....................start..................

/*  MOBILE MENU */

const menuBtn = document.getElementById("menuBtn");
const closeMenu = document.getElementById("closeMenu");
const mobileMenu = document.getElementById("mobileMenu");

menuBtn.addEventListener("click", () => {
    mobileMenu.classList.add("active");
    document.body.classList.add("no-scroll");
});

closeMenu.addEventListener("click", () => {
    mobileMenu.classList.remove("active");
    document.body.classList.remove("no-scroll");
});


/* Close mobile menu after clicking a link */

const mobileLinks = document.querySelectorAll(".mobile-menu a");

mobileLinks.forEach((link) => {

    link.addEventListener("click", () => {

        mobileMenu.classList.remove("active");

        document.body.classList.remove("no-scroll");

    });

});


/*  NAVBAR SCROLL EFFECT */

const navbar = document.getElementById("navbar");

window.addEventListener("scroll", () => {

    if (window.scrollY > 50) {

        navbar.classList.add("scrolled");

    } else {

        navbar.classList.remove("scrolled");

    }

});


/* GALLERY FILTER */

const filterButtons = document.querySelectorAll(".filter-btn");
const galleryCards = document.querySelectorAll(".gallery-card");

filterButtons.forEach((button) => {

    button.addEventListener("click", () => {

        /* Remove active class */

        filterButtons.forEach((btn) => {
            btn.classList.remove("active");
        });

        /* Add active class to clicked button */

        button.classList.add("active");

        const selectedFilter = button.dataset.filter;

        galleryCards.forEach((card) => {

            const category = card.dataset.category;

            if (
                selectedFilter === "all" ||
                category === selectedFilter
            ) {

                card.classList.remove("hide");

            } else {

                card.classList.add("hide");

            }

        });

    });

});

/* CONTACT FORM */

const contactForm =
    document.querySelector(".contact-form");

contactForm.addEventListener("submit", (event) => {

    event.preventDefault();

    const button =
        contactForm.querySelector("button");

    const originalText = button.textContent;

    button.textContent = "Message Sent ✓";

    button.disabled = true;

    setTimeout(() => {

        button.textContent = originalText;

        button.disabled = false;

        contactForm.reset();

    }, 2500);

});


/* INITIALIZE */

console.log(
    "WanderLens Gallery loaded successfully."
);

// ...................end....................