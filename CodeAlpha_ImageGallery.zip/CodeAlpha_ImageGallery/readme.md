

# WanderLens — Image Gallery Website

WanderLens is a modern, responsive image gallery website created as a **CodeAlpha Frontend Development Internship** project. The website presents a curated collection of nature, travel, and city photography with a cinematic dark interface.

## 🌍 About the Website

WanderLens is designed to let visitors explore beautiful destinations and photography through a clean, premium-style gallery experience. The website combines responsive layouts, image-based storytelling, category filtering, smooth navigation, and a simple contact interaction.

## ✨ Main Features

- Responsive design for desktop, tablet, and mobile screens
- Full-screen hero section with cinematic travel imagery
- Fixed glass-style navigation bar
- Mobile navigation menu with open/close functionality
- Smooth scrolling between website sections
- Gallery section with category filters:
  - All
  - Nature
  - Travel
  - City
- Hover effects and image zoom animations
- Location and destination labels on gallery images
- Lazy loading for gallery images to improve page performance
- About / story section
- Explore Collections section
- Contact form with front-end submission feedback
- Responsive footer with navigation links
- Dark, premium visual design
- Material Symbols icons
- Semantic HTML structure and descriptive image alt text

## 🧩 Website Sections

### 1. Home / Hero
Introduces WanderLens with a large background image, headline, short description, and buttons for exploring the gallery and collections.

### 2. Featured Gallery
Displays photography cards divided into Nature, Travel, and City categories. Visitors can filter the gallery using the category buttons.

### 3. About WanderLens
Explains the idea behind the project and presents the website as a curated visual collection of memorable moments and destinations.

### 4. Explore Collections
Highlights the three main photography collections:

- Nature
- Travel
- City

### 5. Contact
Provides a simple contact form where users can enter their name, email, and message. The form currently provides front-end confirmation without sending data to a server.

### 6. Footer
Contains the WanderLens brand description, navigation links, and project/author credit.

## 🛠️ Technologies Used

- **HTML5** — Website structure and semantic content
- **CSS3** — Layout, styling, animations, responsive design, hover effects, and visual effects
- **JavaScript (ES6)** — Interactive functionality
- **Material Symbols** — Navigation and interface icons
- **Responsive CSS Media Queries** — Tablet and mobile layouts

## ⚙️ JavaScript Functionality

The JavaScript file handles the main interactive features of the website:

1. Opens and closes the mobile navigation menu.
2. Prevents page scrolling while the mobile menu is open.
3. Automatically closes the mobile menu after selecting a navigation link.
4. Changes the navbar appearance when the user scrolls down.
5. Filters gallery cards according to the selected category.
6. Displays a temporary **“Message Sent ✓”** confirmation when the contact form is submitted.
7. Resets the contact form after the confirmation message.
8. Logs a successful website-load message in the browser console.

## 📁 Project Structure

CodeAlpha_ImageGallery/
│
├── index.html
├── README.md
│
├── css/
│   ├── style.css
│
├── js/
│   └── script.js
│
└── assets/
    └── images/
        ├── hero.jpg
        ├── about.jpg
        ├── nature.jpg
        ├── nature-1.jpg
        ├── nature-2.jpg
        ├── nature-3.jpg
        ├── travel.jpg
        ├── travel-1.jpg
        ├── travel-2jpg.jpg
        ├── travel-3.jpg
        ├── city.jpg
        ├── city-1.jpg
        ├── city-2.jpg
        ├── city-3.jpg
        ├── karachi.jpg
        ├── larkana.jpg
        ├── Blochistan.jpg
        ├── Rome, Italy.jpg
        └── thailand.jpg

## 🚀 How to Run the Project

No installation or build process is required.

1. Download or clone the project.
2. Open the `CodeAlpha_ImageGallery` folder.
3. Open `index.html` in a modern web browser.
4. Explore the navigation, gallery filters, categories, and contact form.

For the best development experience, open the project in **Visual Studio Code** and use a local server such as Live Server.

## 📱 Responsive Design

The website includes responsive layouts for:

- Desktop screens
- Tablets
- Mobile phones

CSS media queries adjust navigation, gallery columns, category cards, typography, spacing, buttons, and footer layout for smaller screens.

## 🎨 Design Style

WanderLens uses a premium editorial photography style with:

- Dark background
- Warm accent color
- Large serif headings
- Cinematic image overlays
- Glass-style navigation
- Smooth transitions and image zoom effects
- Minimal and modern spacing

## 📸 Featured Destinations

The gallery includes destinations and locations such as:

- Hunza Valley, Pakistan
- Skardu, Pakistan
- Balochistan
- Karachi
- Larkana
- Dubai, UAE
- Turkey
- Indonesia
- Rome, Italy
- Thailand
- Switzerland
- New York / USA themed city imagery

## 📌 Project Purpose

This website was developed to demonstrate practical frontend development skills including:

- Building a complete responsive webpage
- Structuring a real-world website with HTML5
- Creating a modern UI with CSS3
- Adding JavaScript interactions
- Working with local image assets
- Creating responsive layouts
- Implementing category-based filtering
- Improving basic image loading performance
- Organizing a frontend project into reusable folders

## 👨‍💻 Developer

**Tanveer Hussain**

Frontend Development Student & Developer

**Project:** CodeAlpha Frontend Development Internship

**Project Type:** Image Gallery Website

## 📄 Internship

This project was created as part of the **CodeAlpha Frontend Development Internship**.

## 📜 License

This project is created for educational and portfolio purposes. Image rights belong to their respective owners where applicable.

---

**WanderLens — Explore the world through images.**
